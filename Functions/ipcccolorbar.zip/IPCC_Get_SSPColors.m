function  line_color = IPCC_Get_SSPColors(ssp)
% IPCC_Get_SSPColors - Function to extract IPCC SSP Colors (Dec 2018)
% Also cselects linestyle if no_of_colors >6
% Input variables:
%           ssp - name of ssp i.e. 'ssp126', 'ssp245', 'ssp370', 'ssp585'
%           shading_on - If this is ==true then select shading rather than
%           line color for ssp (optional argument

% Define reference line colors for 1-6 colours

if contains(ssp, "585")
    line_color = [132 11 34]/255;
elseif contains(ssp, "370")
    line_color = [242 17 17]/255;
elseif contains(ssp, "245")
    line_color = [234 221 61]/255;
elseif contains(ssp, "126")
    line_color = [29 51 84]/255;
elseif contains(ssp, "119")
    line_color = [30 150 132]/255;
end

end

